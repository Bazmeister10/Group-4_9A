﻿using UnityEngine;
using System.Collections;

public class MoveCamera : MonoBehaviour
{
    private float lockPos;
    private float horizontalSpeed = 3.0F;
    private float verticalSpeed = 3.0F;

    void start ()
    {
        lockPos = 0.0f;
    }

    void Update()
    {
        float h = horizontalSpeed * Input.GetAxis("Mouse X");
        float v = verticalSpeed * Input.GetAxis("Mouse Y");
        transform.Rotate(v * -1, h, lockPos);

        transform.localRotation = Quaternion.Euler(transform.rotation.eulerAngles.x, lockPos, lockPos);
    }
}