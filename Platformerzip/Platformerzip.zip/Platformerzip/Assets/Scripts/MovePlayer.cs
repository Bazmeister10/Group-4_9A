﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlayer : MonoBehaviour {

	public float speed;

    private float lockPos;

    public float jump;

    private Rigidbody rb;

	private Vector3 movement;

    private float horizontalSpeed = 3.0F;

    void Start () {

        rb = GetComponent<Rigidbody>();

        lockPos = 0.0f;
    }

	void Update () {

		Vector3 movement = new Vector3 (speed * Input.GetAxis("Horizontal") * Time.deltaTime, 0f, speed * Input.GetAxis("Vertical") * Time.deltaTime);

	    transform.Translate (movement);

        float h = horizontalSpeed * Input.GetAxis("Mouse X");

        transform.Rotate(lockPos, h, lockPos);

        transform.rotation = Quaternion.Euler(lockPos, transform.rotation.eulerAngles.y, lockPos);

        if (Input.GetKeyDown("space"))
        {
            startjump();
        }

    }

    void startjump()
    {

        rb.AddForce(0, jump, 0);

    }

}